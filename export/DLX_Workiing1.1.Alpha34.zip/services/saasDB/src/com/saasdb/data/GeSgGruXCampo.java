
package com.saasdb.data;



/**
 *  saasDB.GeSgGruXCampo
 *  01/08/2013 14:21:13
 * 
 */
public class GeSgGruXCampo {

    private Integer gesggxaid;
    private GeSgGrupos geSgGrupos;
    private Integer gesggxaidcampo;
    private String gesggxavisib;
    private String gesggxahabilit;
    private String gesggxaobrig;
    private String gesggxatrilha;

    public Integer getGesggxaid() {
        return gesggxaid;
    }

    public void setGesggxaid(Integer gesggxaid) {
        this.gesggxaid = gesggxaid;
    }

    public GeSgGrupos getGeSgGrupos() {
        return geSgGrupos;
    }

    public void setGeSgGrupos(GeSgGrupos geSgGrupos) {
        this.geSgGrupos = geSgGrupos;
    }

    public Integer getGesggxaidcampo() {
        return gesggxaidcampo;
    }

    public void setGesggxaidcampo(Integer gesggxaidcampo) {
        this.gesggxaidcampo = gesggxaidcampo;
    }

    public String getGesggxavisib() {
        return gesggxavisib;
    }

    public void setGesggxavisib(String gesggxavisib) {
        this.gesggxavisib = gesggxavisib;
    }

    public String getGesggxahabilit() {
        return gesggxahabilit;
    }

    public void setGesggxahabilit(String gesggxahabilit) {
        this.gesggxahabilit = gesggxahabilit;
    }

    public String getGesggxaobrig() {
        return gesggxaobrig;
    }

    public void setGesggxaobrig(String gesggxaobrig) {
        this.gesggxaobrig = gesggxaobrig;
    }

    public String getGesggxatrilha() {
        return gesggxatrilha;
    }

    public void setGesggxatrilha(String gesggxatrilha) {
        this.gesggxatrilha = gesggxatrilha;
    }

}
