
package com.saasdb.data;



/**
 *  saasDB.GeSgGruXCompo
 *  01/08/2013 14:21:13
 * 
 */
public class GeSgGruXCompo {

    private Integer gesggxcid;
    private GeSgGrupos geSgGrupos;
    private Integer gesggxcidcompo;
    private String gesggxcacessa;
    private String gesggxcinclui;
    private String gesggxcexclui;
    private String gesggxcaltera;
    private String gesggxctemcampos;

    public Integer getGesggxcid() {
        return gesggxcid;
    }

    public void setGesggxcid(Integer gesggxcid) {
        this.gesggxcid = gesggxcid;
    }

    public GeSgGrupos getGeSgGrupos() {
        return geSgGrupos;
    }

    public void setGeSgGrupos(GeSgGrupos geSgGrupos) {
        this.geSgGrupos = geSgGrupos;
    }

    public Integer getGesggxcidcompo() {
        return gesggxcidcompo;
    }

    public void setGesggxcidcompo(Integer gesggxcidcompo) {
        this.gesggxcidcompo = gesggxcidcompo;
    }

    public String getGesggxcacessa() {
        return gesggxcacessa;
    }

    public void setGesggxcacessa(String gesggxcacessa) {
        this.gesggxcacessa = gesggxcacessa;
    }

    public String getGesggxcinclui() {
        return gesggxcinclui;
    }

    public void setGesggxcinclui(String gesggxcinclui) {
        this.gesggxcinclui = gesggxcinclui;
    }

    public String getGesggxcexclui() {
        return gesggxcexclui;
    }

    public void setGesggxcexclui(String gesggxcexclui) {
        this.gesggxcexclui = gesggxcexclui;
    }

    public String getGesggxcaltera() {
        return gesggxcaltera;
    }

    public void setGesggxcaltera(String gesggxcaltera) {
        this.gesggxcaltera = gesggxcaltera;
    }

    public String getGesggxctemcampos() {
        return gesggxctemcampos;
    }

    public void setGesggxctemcampos(String gesggxctemcampos) {
        this.gesggxctemcampos = gesggxctemcampos;
    }

}
