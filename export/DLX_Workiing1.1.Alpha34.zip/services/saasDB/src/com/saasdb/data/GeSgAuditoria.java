
package com.saasdb.data;



/**
 *  saasDB.GeSgAuditoria
 *  01/08/2013 14:21:12
 * 
 */
public class GeSgAuditoria {

    private Integer gesgaudid;
    private GeSgUsuarios geSgUsuarios;
    private Integer gesgaudcompoid;
    private Integer gesgauddata;
    private String gesgaudacao;
    private String gesgaudchave;
    private String gesgaudinformacao;

    public Integer getGesgaudid() {
        return gesgaudid;
    }

    public void setGesgaudid(Integer gesgaudid) {
        this.gesgaudid = gesgaudid;
    }

    public GeSgUsuarios getGeSgUsuarios() {
        return geSgUsuarios;
    }

    public void setGeSgUsuarios(GeSgUsuarios geSgUsuarios) {
        this.geSgUsuarios = geSgUsuarios;
    }

    public Integer getGesgaudcompoid() {
        return gesgaudcompoid;
    }

    public void setGesgaudcompoid(Integer gesgaudcompoid) {
        this.gesgaudcompoid = gesgaudcompoid;
    }

    public Integer getGesgauddata() {
        return gesgauddata;
    }

    public void setGesgauddata(Integer gesgauddata) {
        this.gesgauddata = gesgauddata;
    }

    public String getGesgaudacao() {
        return gesgaudacao;
    }

    public void setGesgaudacao(String gesgaudacao) {
        this.gesgaudacao = gesgaudacao;
    }

    public String getGesgaudchave() {
        return gesgaudchave;
    }

    public void setGesgaudchave(String gesgaudchave) {
        this.gesgaudchave = gesgaudchave;
    }

    public String getGesgaudinformacao() {
        return gesgaudinformacao;
    }

    public void setGesgaudinformacao(String gesgaudinformacao) {
        this.gesgaudinformacao = gesgaudinformacao;
    }

}
