
package com.saasdb.data;



/**
 *  saasDB.GeCaEmpDocsPf
 *  01/08/2013 14:21:13
 * 
 */
public class GeCaEmpDocsPf {

    private Integer geempdpfempresaid;
    private com.saasdb.data.GeTbUf geTbUfByGeempdpfrguf;
    private com.saasdb.data.GeTbUf geTbUfByGeempdpfregprofuf;
    private String geempdpfcpf;
    private String geempdpfrg;
    private String geempdpfrgorgao;
    private String geempdpfregprof;

    public Integer getGeempdpfempresaid() {
        return geempdpfempresaid;
    }

    public void setGeempdpfempresaid(Integer geempdpfempresaid) {
        this.geempdpfempresaid = geempdpfempresaid;
    }

    public com.saasdb.data.GeTbUf getGeTbUfByGeempdpfrguf() {
        return geTbUfByGeempdpfrguf;
    }

    public void setGeTbUfByGeempdpfrguf(com.saasdb.data.GeTbUf geTbUfByGeempdpfrguf) {
        this.geTbUfByGeempdpfrguf = geTbUfByGeempdpfrguf;
    }

    public com.saasdb.data.GeTbUf getGeTbUfByGeempdpfregprofuf() {
        return geTbUfByGeempdpfregprofuf;
    }

    public void setGeTbUfByGeempdpfregprofuf(com.saasdb.data.GeTbUf geTbUfByGeempdpfregprofuf) {
        this.geTbUfByGeempdpfregprofuf = geTbUfByGeempdpfregprofuf;
    }

    public String getGeempdpfcpf() {
        return geempdpfcpf;
    }

    public void setGeempdpfcpf(String geempdpfcpf) {
        this.geempdpfcpf = geempdpfcpf;
    }

    public String getGeempdpfrg() {
        return geempdpfrg;
    }

    public void setGeempdpfrg(String geempdpfrg) {
        this.geempdpfrg = geempdpfrg;
    }

    public String getGeempdpfrgorgao() {
        return geempdpfrgorgao;
    }

    public void setGeempdpfrgorgao(String geempdpfrgorgao) {
        this.geempdpfrgorgao = geempdpfrgorgao;
    }

    public String getGeempdpfregprof() {
        return geempdpfregprof;
    }

    public void setGeempdpfregprof(String geempdpfregprof) {
        this.geempdpfregprof = geempdpfregprof;
    }

}
