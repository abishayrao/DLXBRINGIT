
package com.saasdb.data;



/**
 *  saasDB.GeSgGruXEmpresa
 *  01/08/2013 14:21:12
 * 
 */
public class GeSgGruXEmpresa {

    private Integer gesggxeid;
    private GeSgGrupos geSgGrupos;
    private GeCaEmpresas geCaEmpresas;

    public Integer getGesggxeid() {
        return gesggxeid;
    }

    public void setGesggxeid(Integer gesggxeid) {
        this.gesggxeid = gesggxeid;
    }

    public GeSgGrupos getGeSgGrupos() {
        return geSgGrupos;
    }

    public void setGeSgGrupos(GeSgGrupos geSgGrupos) {
        this.geSgGrupos = geSgGrupos;
    }

    public GeCaEmpresas getGeCaEmpresas() {
        return geCaEmpresas;
    }

    public void setGeCaEmpresas(GeCaEmpresas geCaEmpresas) {
        this.geCaEmpresas = geCaEmpresas;
    }

}
