
package com.saasdb.data;



/**
 *  saasDB.SiCliDocsPf
 *  01/08/2013 14:21:13
 * 
 */
public class SiCliDocsPf {

    private Integer siclidpfclienteid;
    private GeTbUf geTbUf;
    private String siclidpfcpf;
    private String siclidpfrg;
    private String siclidpfrgorgao;
    private String siclidpfregprof;

    public Integer getSiclidpfclienteid() {
        return siclidpfclienteid;
    }

    public void setSiclidpfclienteid(Integer siclidpfclienteid) {
        this.siclidpfclienteid = siclidpfclienteid;
    }

    public GeTbUf getGeTbUf() {
        return geTbUf;
    }

    public void setGeTbUf(GeTbUf geTbUf) {
        this.geTbUf = geTbUf;
    }

    public String getSiclidpfcpf() {
        return siclidpfcpf;
    }

    public void setSiclidpfcpf(String siclidpfcpf) {
        this.siclidpfcpf = siclidpfcpf;
    }

    public String getSiclidpfrg() {
        return siclidpfrg;
    }

    public void setSiclidpfrg(String siclidpfrg) {
        this.siclidpfrg = siclidpfrg;
    }

    public String getSiclidpfrgorgao() {
        return siclidpfrgorgao;
    }

    public void setSiclidpfrgorgao(String siclidpfrgorgao) {
        this.siclidpfrgorgao = siclidpfrgorgao;
    }

    public String getSiclidpfregprof() {
        return siclidpfregprof;
    }

    public void setSiclidpfregprof(String siclidpfregprof) {
        this.siclidpfregprof = siclidpfregprof;
    }

}
