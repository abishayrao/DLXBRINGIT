
package com.saasdb.data;



/**
 *  saasDB.GeCaEmpEnd
 *  01/08/2013 14:21:12
 * 
 */
public class GeCaEmpEnd {

    private Integer geempendid;
    private GeCaEmpresas geCaEmpresas;
    private GeTbTiposEndereco geTbTiposEndereco;
    private GeTbUf geTbUf;
    private String geempendlogra;
    private String geempendno;
    private String geempendcompl;
    private String geempendbairro;
    private String geempendmunic;
    private String geempendcep;

    public Integer getGeempendid() {
        return geempendid;
    }

    public void setGeempendid(Integer geempendid) {
        this.geempendid = geempendid;
    }

    public GeCaEmpresas getGeCaEmpresas() {
        return geCaEmpresas;
    }

    public void setGeCaEmpresas(GeCaEmpresas geCaEmpresas) {
        this.geCaEmpresas = geCaEmpresas;
    }

    public GeTbTiposEndereco getGeTbTiposEndereco() {
        return geTbTiposEndereco;
    }

    public void setGeTbTiposEndereco(GeTbTiposEndereco geTbTiposEndereco) {
        this.geTbTiposEndereco = geTbTiposEndereco;
    }

    public GeTbUf getGeTbUf() {
        return geTbUf;
    }

    public void setGeTbUf(GeTbUf geTbUf) {
        this.geTbUf = geTbUf;
    }

    public String getGeempendlogra() {
        return geempendlogra;
    }

    public void setGeempendlogra(String geempendlogra) {
        this.geempendlogra = geempendlogra;
    }

    public String getGeempendno() {
        return geempendno;
    }

    public void setGeempendno(String geempendno) {
        this.geempendno = geempendno;
    }

    public String getGeempendcompl() {
        return geempendcompl;
    }

    public void setGeempendcompl(String geempendcompl) {
        this.geempendcompl = geempendcompl;
    }

    public String getGeempendbairro() {
        return geempendbairro;
    }

    public void setGeempendbairro(String geempendbairro) {
        this.geempendbairro = geempendbairro;
    }

    public String getGeempendmunic() {
        return geempendmunic;
    }

    public void setGeempendmunic(String geempendmunic) {
        this.geempendmunic = geempendmunic;
    }

    public String getGeempendcep() {
        return geempendcep;
    }

    public void setGeempendcep(String geempendcep) {
        this.geempendcep = geempendcep;
    }

}
