
package com.saasdb.data;

import java.util.Date;


/**
 *  saasDB.SiCliDocsPj
 *  01/08/2013 14:21:12
 * 
 */
public class SiCliDocsPj {

    private Integer siclidpjclienteid;
    private String siclidpjcnpj;
    private String siclidpjie;
    private Date siclidpjiedata;
    private String siclidpjim;

    public Integer getSiclidpjclienteid() {
        return siclidpjclienteid;
    }

    public void setSiclidpjclienteid(Integer siclidpjclienteid) {
        this.siclidpjclienteid = siclidpjclienteid;
    }

    public String getSiclidpjcnpj() {
        return siclidpjcnpj;
    }

    public void setSiclidpjcnpj(String siclidpjcnpj) {
        this.siclidpjcnpj = siclidpjcnpj;
    }

    public String getSiclidpjie() {
        return siclidpjie;
    }

    public void setSiclidpjie(String siclidpjie) {
        this.siclidpjie = siclidpjie;
    }

    public Date getSiclidpjiedata() {
        return siclidpjiedata;
    }

    public void setSiclidpjiedata(Date siclidpjiedata) {
        this.siclidpjiedata = siclidpjiedata;
    }

    public String getSiclidpjim() {
        return siclidpjim;
    }

    public void setSiclidpjim(String siclidpjim) {
        this.siclidpjim = siclidpjim;
    }

}
