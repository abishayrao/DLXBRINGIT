
package com.saasdb.data;

import java.util.Date;


/**
 *  saasDB.GeCaEmpDocsPj
 *  01/08/2013 14:21:13
 * 
 */
public class GeCaEmpDocsPj {

    private Integer geempdpjempresaid;
    private GeTbCnaeSubclasse geTbCnaeSubclasse;
    private String geempdpjtipodoc;
    private String geempdpjdoc;
    private String geempdpjie;
    private Date geempdpjiedata;
    private String geempdpjim;
    private Date geempdpjimdata;

    public Integer getGeempdpjempresaid() {
        return geempdpjempresaid;
    }

    public void setGeempdpjempresaid(Integer geempdpjempresaid) {
        this.geempdpjempresaid = geempdpjempresaid;
    }

    public GeTbCnaeSubclasse getGeTbCnaeSubclasse() {
        return geTbCnaeSubclasse;
    }

    public void setGeTbCnaeSubclasse(GeTbCnaeSubclasse geTbCnaeSubclasse) {
        this.geTbCnaeSubclasse = geTbCnaeSubclasse;
    }

    public String getGeempdpjtipodoc() {
        return geempdpjtipodoc;
    }

    public void setGeempdpjtipodoc(String geempdpjtipodoc) {
        this.geempdpjtipodoc = geempdpjtipodoc;
    }

    public String getGeempdpjdoc() {
        return geempdpjdoc;
    }

    public void setGeempdpjdoc(String geempdpjdoc) {
        this.geempdpjdoc = geempdpjdoc;
    }

    public String getGeempdpjie() {
        return geempdpjie;
    }

    public void setGeempdpjie(String geempdpjie) {
        this.geempdpjie = geempdpjie;
    }

    public Date getGeempdpjiedata() {
        return geempdpjiedata;
    }

    public void setGeempdpjiedata(Date geempdpjiedata) {
        this.geempdpjiedata = geempdpjiedata;
    }

    public String getGeempdpjim() {
        return geempdpjim;
    }

    public void setGeempdpjim(String geempdpjim) {
        this.geempdpjim = geempdpjim;
    }

    public Date getGeempdpjimdata() {
        return geempdpjimdata;
    }

    public void setGeempdpjimdata(Date geempdpjimdata) {
        this.geempdpjimdata = geempdpjimdata;
    }

}
