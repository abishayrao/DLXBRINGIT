
package com.saasdb;



/**
 *  Query names for service "saasDB"
 *  01/08/2013 14:21:09
 * 
 */
public class SaasDBConstants {

    public final static String getGeTbBcAgenciasByIdQueryName = "getGeTbBcAgenciasById";

}
