
package com.testdb.data;



/**
 *  testDB.GeCaEmpTel
 *  02/23/2013 10:50:04
 * 
 */
public class GeCaEmpTel {

    private Integer geemptelid;
    private GeCaEmpresas geCaEmpresas;
    private GeTbTiposTelefone geTbTiposTelefone;
    private String geemptelddd;
    private String geemptelno;
    private String geemptelramal;

    public Integer getGeemptelid() {
        return geemptelid;
    }

    public void setGeemptelid(Integer geemptelid) {
        this.geemptelid = geemptelid;
    }

    public GeCaEmpresas getGeCaEmpresas() {
        return geCaEmpresas;
    }

    public void setGeCaEmpresas(GeCaEmpresas geCaEmpresas) {
        this.geCaEmpresas = geCaEmpresas;
    }

    public GeTbTiposTelefone getGeTbTiposTelefone() {
        return geTbTiposTelefone;
    }

    public void setGeTbTiposTelefone(GeTbTiposTelefone geTbTiposTelefone) {
        this.geTbTiposTelefone = geTbTiposTelefone;
    }

    public String getGeemptelddd() {
        return geemptelddd;
    }

    public void setGeemptelddd(String geemptelddd) {
        this.geemptelddd = geemptelddd;
    }

    public String getGeemptelno() {
        return geemptelno;
    }

    public void setGeemptelno(String geemptelno) {
        this.geemptelno = geemptelno;
    }

    public String getGeemptelramal() {
        return geemptelramal;
    }

    public void setGeemptelramal(String geemptelramal) {
        this.geemptelramal = geemptelramal;
    }

}
