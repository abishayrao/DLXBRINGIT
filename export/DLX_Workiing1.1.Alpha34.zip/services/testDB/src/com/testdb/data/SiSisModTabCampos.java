
package com.testdb.data;



/**
 *  testDB.SiSisModTabCampos
 *  02/23/2013 10:50:05
 * 
 */
public class SiSisModTabCampos {

    private Integer sismtcid;
    private SiSisModTabelas siSisModTabelas;
    private String sismtcnome;
    private String sismtcatributo;
    private String sismtctipo;
    private String sismtcnulo;
    private String sismtcpk;
    private String sismtcfk;
    private String sismtcuk;
    private String sismtcdescricao;

    public Integer getSismtcid() {
        return sismtcid;
    }

    public void setSismtcid(Integer sismtcid) {
        this.sismtcid = sismtcid;
    }

    public SiSisModTabelas getSiSisModTabelas() {
        return siSisModTabelas;
    }

    public void setSiSisModTabelas(SiSisModTabelas siSisModTabelas) {
        this.siSisModTabelas = siSisModTabelas;
    }

    public String getSismtcnome() {
        return sismtcnome;
    }

    public void setSismtcnome(String sismtcnome) {
        this.sismtcnome = sismtcnome;
    }

    public String getSismtcatributo() {
        return sismtcatributo;
    }

    public void setSismtcatributo(String sismtcatributo) {
        this.sismtcatributo = sismtcatributo;
    }

    public String getSismtctipo() {
        return sismtctipo;
    }

    public void setSismtctipo(String sismtctipo) {
        this.sismtctipo = sismtctipo;
    }

    public String getSismtcnulo() {
        return sismtcnulo;
    }

    public void setSismtcnulo(String sismtcnulo) {
        this.sismtcnulo = sismtcnulo;
    }

    public String getSismtcpk() {
        return sismtcpk;
    }

    public void setSismtcpk(String sismtcpk) {
        this.sismtcpk = sismtcpk;
    }

    public String getSismtcfk() {
        return sismtcfk;
    }

    public void setSismtcfk(String sismtcfk) {
        this.sismtcfk = sismtcfk;
    }

    public String getSismtcuk() {
        return sismtcuk;
    }

    public void setSismtcuk(String sismtcuk) {
        this.sismtcuk = sismtcuk;
    }

    public String getSismtcdescricao() {
        return sismtcdescricao;
    }

    public void setSismtcdescricao(String sismtcdescricao) {
        this.sismtcdescricao = sismtcdescricao;
    }

}
