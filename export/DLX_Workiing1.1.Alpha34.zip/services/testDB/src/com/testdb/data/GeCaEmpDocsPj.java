
package com.testdb.data;

import java.util.Date;


/**
 *  testDB.GeCaEmpDocsPj
 *  02/23/2013 10:50:05
 * 
 */
public class GeCaEmpDocsPj {

    private Integer geempdpjempresaid;
    private GeTbCnaeSubclasse geTbCnaeSubclasse;
    private GeCaEmpresas geCaEmpresas;
    private String geempdpjtipodoc;
    private String geempdpjdoc;
    private String geempdpjie;
    private Date geempdpjiedata;
    private String geempdpjim;
    private Date geempdpjimdata;

    public Integer getGeempdpjempresaid() {
        return geempdpjempresaid;
    }

    public void setGeempdpjempresaid(Integer geempdpjempresaid) {
        this.geempdpjempresaid = geempdpjempresaid;
    }

    public GeTbCnaeSubclasse getGeTbCnaeSubclasse() {
        return geTbCnaeSubclasse;
    }

    public void setGeTbCnaeSubclasse(GeTbCnaeSubclasse geTbCnaeSubclasse) {
        this.geTbCnaeSubclasse = geTbCnaeSubclasse;
    }

    public GeCaEmpresas getGeCaEmpresas() {
        return geCaEmpresas;
    }

    public void setGeCaEmpresas(GeCaEmpresas geCaEmpresas) {
        this.geCaEmpresas = geCaEmpresas;
    }

    public String getGeempdpjtipodoc() {
        return geempdpjtipodoc;
    }

    public void setGeempdpjtipodoc(String geempdpjtipodoc) {
        this.geempdpjtipodoc = geempdpjtipodoc;
    }

    public String getGeempdpjdoc() {
        return geempdpjdoc;
    }

    public void setGeempdpjdoc(String geempdpjdoc) {
        this.geempdpjdoc = geempdpjdoc;
    }

    public String getGeempdpjie() {
        return geempdpjie;
    }

    public void setGeempdpjie(String geempdpjie) {
        this.geempdpjie = geempdpjie;
    }

    public Date getGeempdpjiedata() {
        return geempdpjiedata;
    }

    public void setGeempdpjiedata(Date geempdpjiedata) {
        this.geempdpjiedata = geempdpjiedata;
    }

    public String getGeempdpjim() {
        return geempdpjim;
    }

    public void setGeempdpjim(String geempdpjim) {
        this.geempdpjim = geempdpjim;
    }

    public Date getGeempdpjimdata() {
        return geempdpjimdata;
    }

    public void setGeempdpjimdata(Date geempdpjimdata) {
        this.geempdpjimdata = geempdpjimdata;
    }

}
