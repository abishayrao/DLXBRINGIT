
package com.testdb.data;



/**
 *  testDB.StEpFabricTel
 *  02/23/2013 10:50:04
 * 
 */
public class StEpFabricTel {

    private Integer stfatelid;
    private GeTbTiposTelefone geTbTiposTelefone;
    private StEpFabricantes stEpFabricantes;
    private String stfatelddd;
    private String stfatelno;
    private String stfatelramal;

    public Integer getStfatelid() {
        return stfatelid;
    }

    public void setStfatelid(Integer stfatelid) {
        this.stfatelid = stfatelid;
    }

    public GeTbTiposTelefone getGeTbTiposTelefone() {
        return geTbTiposTelefone;
    }

    public void setGeTbTiposTelefone(GeTbTiposTelefone geTbTiposTelefone) {
        this.geTbTiposTelefone = geTbTiposTelefone;
    }

    public StEpFabricantes getStEpFabricantes() {
        return stEpFabricantes;
    }

    public void setStEpFabricantes(StEpFabricantes stEpFabricantes) {
        this.stEpFabricantes = stEpFabricantes;
    }

    public String getStfatelddd() {
        return stfatelddd;
    }

    public void setStfatelddd(String stfatelddd) {
        this.stfatelddd = stfatelddd;
    }

    public String getStfatelno() {
        return stfatelno;
    }

    public void setStfatelno(String stfatelno) {
        this.stfatelno = stfatelno;
    }

    public String getStfatelramal() {
        return stfatelramal;
    }

    public void setStfatelramal(String stfatelramal) {
        this.stfatelramal = stfatelramal;
    }

}
