
package com.testdb.data;



/**
 *  testDB.GeCaFuncionario
 *  02/23/2013 10:50:04
 * 
 */
public class GeCaFuncionario {

    private Integer gefunciid;
    private GeCaEmpresas geCaEmpresas;
    private Integer gefuncimatricula;
    private Integer gefuncidigito;
    private String gefuncinome;
    private String gefuncinomecomplet;
    private String gefuncistatus;
    private String gefunciidmestre;
    private String gefuncialteradomes;

    public Integer getGefunciid() {
        return gefunciid;
    }

    public void setGefunciid(Integer gefunciid) {
        this.gefunciid = gefunciid;
    }

    public GeCaEmpresas getGeCaEmpresas() {
        return geCaEmpresas;
    }

    public void setGeCaEmpresas(GeCaEmpresas geCaEmpresas) {
        this.geCaEmpresas = geCaEmpresas;
    }

    public Integer getGefuncimatricula() {
        return gefuncimatricula;
    }

    public void setGefuncimatricula(Integer gefuncimatricula) {
        this.gefuncimatricula = gefuncimatricula;
    }

    public Integer getGefuncidigito() {
        return gefuncidigito;
    }

    public void setGefuncidigito(Integer gefuncidigito) {
        this.gefuncidigito = gefuncidigito;
    }

    public String getGefuncinome() {
        return gefuncinome;
    }

    public void setGefuncinome(String gefuncinome) {
        this.gefuncinome = gefuncinome;
    }

    public String getGefuncinomecomplet() {
        return gefuncinomecomplet;
    }

    public void setGefuncinomecomplet(String gefuncinomecomplet) {
        this.gefuncinomecomplet = gefuncinomecomplet;
    }

    public String getGefuncistatus() {
        return gefuncistatus;
    }

    public void setGefuncistatus(String gefuncistatus) {
        this.gefuncistatus = gefuncistatus;
    }

    public String getGefunciidmestre() {
        return gefunciidmestre;
    }

    public void setGefunciidmestre(String gefunciidmestre) {
        this.gefunciidmestre = gefunciidmestre;
    }

    public String getGefuncialteradomes() {
        return gefuncialteradomes;
    }

    public void setGefuncialteradomes(String gefuncialteradomes) {
        this.gefuncialteradomes = gefuncialteradomes;
    }

}
