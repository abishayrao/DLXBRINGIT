
package com.testdb.data;

import java.util.Date;


/**
 *  testDB.SiCliDocsPj
 *  02/23/2013 10:50:05
 * 
 */
public class SiCliDocsPj {

    private Integer siclidpjclienteid;
    private SiClientes siClientes;
    private String siclidpjcnpj;
    private String siclidpjie;
    private Date siclidpjiedata;
    private String siclidpjim;

    public Integer getSiclidpjclienteid() {
        return siclidpjclienteid;
    }

    public void setSiclidpjclienteid(Integer siclidpjclienteid) {
        this.siclidpjclienteid = siclidpjclienteid;
    }

    public SiClientes getSiClientes() {
        return siClientes;
    }

    public void setSiClientes(SiClientes siClientes) {
        this.siClientes = siClientes;
    }

    public String getSiclidpjcnpj() {
        return siclidpjcnpj;
    }

    public void setSiclidpjcnpj(String siclidpjcnpj) {
        this.siclidpjcnpj = siclidpjcnpj;
    }

    public String getSiclidpjie() {
        return siclidpjie;
    }

    public void setSiclidpjie(String siclidpjie) {
        this.siclidpjie = siclidpjie;
    }

    public Date getSiclidpjiedata() {
        return siclidpjiedata;
    }

    public void setSiclidpjiedata(Date siclidpjiedata) {
        this.siclidpjiedata = siclidpjiedata;
    }

    public String getSiclidpjim() {
        return siclidpjim;
    }

    public void setSiclidpjim(String siclidpjim) {
        this.siclidpjim = siclidpjim;
    }

}
