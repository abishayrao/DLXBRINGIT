
package com.testdb.data;



/**
 *  testDB.GeCaEmpWeb
 *  02/23/2013 10:50:04
 * 
 */
public class GeCaEmpWeb {

    private Integer geempwebid;
    private GeTbTiposWeb geTbTiposWeb;
    private GeCaEmpresas geCaEmpresas;
    private String geempwebtxt;

    public Integer getGeempwebid() {
        return geempwebid;
    }

    public void setGeempwebid(Integer geempwebid) {
        this.geempwebid = geempwebid;
    }

    public GeTbTiposWeb getGeTbTiposWeb() {
        return geTbTiposWeb;
    }

    public void setGeTbTiposWeb(GeTbTiposWeb geTbTiposWeb) {
        this.geTbTiposWeb = geTbTiposWeb;
    }

    public GeCaEmpresas getGeCaEmpresas() {
        return geCaEmpresas;
    }

    public void setGeCaEmpresas(GeCaEmpresas geCaEmpresas) {
        this.geCaEmpresas = geCaEmpresas;
    }

    public String getGeempwebtxt() {
        return geempwebtxt;
    }

    public void setGeempwebtxt(String geempwebtxt) {
        this.geempwebtxt = geempwebtxt;
    }

}
