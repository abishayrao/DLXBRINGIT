
package com.testdb.data;



/**
 *  testDB.GeSgAuditoria
 *  02/23/2013 10:50:05
 * 
 */
public class GeSgAuditoria {

    private Integer gesgaudId;
    private GeSgUsuarios geSgUsuarios;
    private Integer gesgaudCompoId;
    private Integer gesgaudData;
    private String gesgaudAcao;
    private String gesgaudChave;
    private String gesgaudInformacao;

    public Integer getGesgaudId() {
        return gesgaudId;
    }

    public void setGesgaudId(Integer gesgaudId) {
        this.gesgaudId = gesgaudId;
    }

    public GeSgUsuarios getGeSgUsuarios() {
        return geSgUsuarios;
    }

    public void setGeSgUsuarios(GeSgUsuarios geSgUsuarios) {
        this.geSgUsuarios = geSgUsuarios;
    }

    public Integer getGesgaudCompoId() {
        return gesgaudCompoId;
    }

    public void setGesgaudCompoId(Integer gesgaudCompoId) {
        this.gesgaudCompoId = gesgaudCompoId;
    }

    public Integer getGesgaudData() {
        return gesgaudData;
    }

    public void setGesgaudData(Integer gesgaudData) {
        this.gesgaudData = gesgaudData;
    }

    public String getGesgaudAcao() {
        return gesgaudAcao;
    }

    public void setGesgaudAcao(String gesgaudAcao) {
        this.gesgaudAcao = gesgaudAcao;
    }

    public String getGesgaudChave() {
        return gesgaudChave;
    }

    public void setGesgaudChave(String gesgaudChave) {
        this.gesgaudChave = gesgaudChave;
    }

    public String getGesgaudInformacao() {
        return gesgaudInformacao;
    }

    public void setGesgaudInformacao(String gesgaudInformacao) {
        this.gesgaudInformacao = gesgaudInformacao;
    }

}
