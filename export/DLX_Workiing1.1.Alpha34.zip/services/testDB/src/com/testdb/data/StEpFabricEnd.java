
package com.testdb.data;



/**
 *  testDB.StEpFabricEnd
 *  02/23/2013 10:50:04
 * 
 */
public class StEpFabricEnd {

    private Integer stfaendid;
    private GeTbUf geTbUf;
    private StEpFabricantes stEpFabricantes;
    private GeTbTiposEndereco geTbTiposEndereco;
    private String stfaendlogra;
    private String stfaendno;
    private String stfaendcompl;
    private String stfaendbairro;
    private String stfaendmunic;
    private String stfaendcep;

    public Integer getStfaendid() {
        return stfaendid;
    }

    public void setStfaendid(Integer stfaendid) {
        this.stfaendid = stfaendid;
    }

    public GeTbUf getGeTbUf() {
        return geTbUf;
    }

    public void setGeTbUf(GeTbUf geTbUf) {
        this.geTbUf = geTbUf;
    }

    public StEpFabricantes getStEpFabricantes() {
        return stEpFabricantes;
    }

    public void setStEpFabricantes(StEpFabricantes stEpFabricantes) {
        this.stEpFabricantes = stEpFabricantes;
    }

    public GeTbTiposEndereco getGeTbTiposEndereco() {
        return geTbTiposEndereco;
    }

    public void setGeTbTiposEndereco(GeTbTiposEndereco geTbTiposEndereco) {
        this.geTbTiposEndereco = geTbTiposEndereco;
    }

    public String getStfaendlogra() {
        return stfaendlogra;
    }

    public void setStfaendlogra(String stfaendlogra) {
        this.stfaendlogra = stfaendlogra;
    }

    public String getStfaendno() {
        return stfaendno;
    }

    public void setStfaendno(String stfaendno) {
        this.stfaendno = stfaendno;
    }

    public String getStfaendcompl() {
        return stfaendcompl;
    }

    public void setStfaendcompl(String stfaendcompl) {
        this.stfaendcompl = stfaendcompl;
    }

    public String getStfaendbairro() {
        return stfaendbairro;
    }

    public void setStfaendbairro(String stfaendbairro) {
        this.stfaendbairro = stfaendbairro;
    }

    public String getStfaendmunic() {
        return stfaendmunic;
    }

    public void setStfaendmunic(String stfaendmunic) {
        this.stfaendmunic = stfaendmunic;
    }

    public String getStfaendcep() {
        return stfaendcep;
    }

    public void setStfaendcep(String stfaendcep) {
        this.stfaendcep = stfaendcep;
    }

}
