
package com.testdb.data;



/**
 *  testDB.SiCliEnd
 *  02/23/2013 10:50:05
 * 
 */
public class SiCliEnd {

    private Integer sicliendid;
    private GeTbTiposEndereco geTbTiposEndereco;
    private GeTbUf geTbUf;
    private SiClientes siClientes;
    private String sicliendlogra;
    private String sicliendno;
    private String sicliendcompl;
    private String sicliendbairro;
    private String sicliendmunic;
    private String sicliendcep;

    public Integer getSicliendid() {
        return sicliendid;
    }

    public void setSicliendid(Integer sicliendid) {
        this.sicliendid = sicliendid;
    }

    public GeTbTiposEndereco getGeTbTiposEndereco() {
        return geTbTiposEndereco;
    }

    public void setGeTbTiposEndereco(GeTbTiposEndereco geTbTiposEndereco) {
        this.geTbTiposEndereco = geTbTiposEndereco;
    }

    public GeTbUf getGeTbUf() {
        return geTbUf;
    }

    public void setGeTbUf(GeTbUf geTbUf) {
        this.geTbUf = geTbUf;
    }

    public SiClientes getSiClientes() {
        return siClientes;
    }

    public void setSiClientes(SiClientes siClientes) {
        this.siClientes = siClientes;
    }

    public String getSicliendlogra() {
        return sicliendlogra;
    }

    public void setSicliendlogra(String sicliendlogra) {
        this.sicliendlogra = sicliendlogra;
    }

    public String getSicliendno() {
        return sicliendno;
    }

    public void setSicliendno(String sicliendno) {
        this.sicliendno = sicliendno;
    }

    public String getSicliendcompl() {
        return sicliendcompl;
    }

    public void setSicliendcompl(String sicliendcompl) {
        this.sicliendcompl = sicliendcompl;
    }

    public String getSicliendbairro() {
        return sicliendbairro;
    }

    public void setSicliendbairro(String sicliendbairro) {
        this.sicliendbairro = sicliendbairro;
    }

    public String getSicliendmunic() {
        return sicliendmunic;
    }

    public void setSicliendmunic(String sicliendmunic) {
        this.sicliendmunic = sicliendmunic;
    }

    public String getSicliendcep() {
        return sicliendcep;
    }

    public void setSicliendcep(String sicliendcep) {
        this.sicliendcep = sicliendcep;
    }

}
