
package com.testdb.data;



/**
 *  testDB.SiCliDocsPf
 *  02/23/2013 10:50:04
 * 
 */
public class SiCliDocsPf {

    private Integer siclidpfclienteid;
    private SiClientes siClientes;
    private GeTbUf geTbUf;
    private String siclidpfcpf;
    private String siclidpfrg;
    private String siclidpfrgorgao;
    private String siclidpfregprof;

    public Integer getSiclidpfclienteid() {
        return siclidpfclienteid;
    }

    public void setSiclidpfclienteid(Integer siclidpfclienteid) {
        this.siclidpfclienteid = siclidpfclienteid;
    }

    public SiClientes getSiClientes() {
        return siClientes;
    }

    public void setSiClientes(SiClientes siClientes) {
        this.siClientes = siClientes;
    }

    public GeTbUf getGeTbUf() {
        return geTbUf;
    }

    public void setGeTbUf(GeTbUf geTbUf) {
        this.geTbUf = geTbUf;
    }

    public String getSiclidpfcpf() {
        return siclidpfcpf;
    }

    public void setSiclidpfcpf(String siclidpfcpf) {
        this.siclidpfcpf = siclidpfcpf;
    }

    public String getSiclidpfrg() {
        return siclidpfrg;
    }

    public void setSiclidpfrg(String siclidpfrg) {
        this.siclidpfrg = siclidpfrg;
    }

    public String getSiclidpfrgorgao() {
        return siclidpfrgorgao;
    }

    public void setSiclidpfrgorgao(String siclidpfrgorgao) {
        this.siclidpfrgorgao = siclidpfrgorgao;
    }

    public String getSiclidpfregprof() {
        return siclidpfregprof;
    }

    public void setSiclidpfregprof(String siclidpfregprof) {
        this.siclidpfregprof = siclidpfregprof;
    }

}
