
package com.testdb.data;



/**
 *  testDB.Selectionandordering
 *  02/23/2013 10:50:05
 * 
 */
public class Selectionandordering {

    private Integer id;
    private String preview;
    private String filter;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPreview() {
        return preview;
    }

    public void setPreview(String preview) {
        this.preview = preview;
    }

    public String getFilter() {
        return filter;
    }

    public void setFilter(String filter) {
        this.filter = filter;
    }

}
