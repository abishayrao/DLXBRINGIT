
package com.testdb.data;

import java.util.Date;


/**
 *  testDB.GeTbTiposContrato
 *  02/23/2013 10:50:05
 * 
 */
public class GeTbTiposContrato {

    private Integer getipoctrid;
    private SiClientes siClientes;
    private String getipoctrcod;
    private String getipoctrdescr;
    private String getipoctrstatus;
    private Date getipoctrinivig;
    private Date getipoctrfimvig;

    public Integer getGetipoctrid() {
        return getipoctrid;
    }

    public void setGetipoctrid(Integer getipoctrid) {
        this.getipoctrid = getipoctrid;
    }

    public SiClientes getSiClientes() {
        return siClientes;
    }

    public void setSiClientes(SiClientes siClientes) {
        this.siClientes = siClientes;
    }

    public String getGetipoctrcod() {
        return getipoctrcod;
    }

    public void setGetipoctrcod(String getipoctrcod) {
        this.getipoctrcod = getipoctrcod;
    }

    public String getGetipoctrdescr() {
        return getipoctrdescr;
    }

    public void setGetipoctrdescr(String getipoctrdescr) {
        this.getipoctrdescr = getipoctrdescr;
    }

    public String getGetipoctrstatus() {
        return getipoctrstatus;
    }

    public void setGetipoctrstatus(String getipoctrstatus) {
        this.getipoctrstatus = getipoctrstatus;
    }

    public Date getGetipoctrinivig() {
        return getipoctrinivig;
    }

    public void setGetipoctrinivig(Date getipoctrinivig) {
        this.getipoctrinivig = getipoctrinivig;
    }

    public Date getGetipoctrfimvig() {
        return getipoctrfimvig;
    }

    public void setGetipoctrfimvig(Date getipoctrfimvig) {
        this.getipoctrfimvig = getipoctrfimvig;
    }

}
