
package com.testdb.data;



/**
 *  testDB.DiHlHelpUsu
 *  02/23/2013 10:50:05
 * 
 */
public class DiHlHelpUsu {

    private Integer dihlhluid;
    private GeSgUsuarios geSgUsuarios;
    private SiSisModComponentes siSisModComponentes;
    private String dihlhludescr;

    public Integer getDihlhluid() {
        return dihlhluid;
    }

    public void setDihlhluid(Integer dihlhluid) {
        this.dihlhluid = dihlhluid;
    }

    public GeSgUsuarios getGeSgUsuarios() {
        return geSgUsuarios;
    }

    public void setGeSgUsuarios(GeSgUsuarios geSgUsuarios) {
        this.geSgUsuarios = geSgUsuarios;
    }

    public SiSisModComponentes getSiSisModComponentes() {
        return siSisModComponentes;
    }

    public void setSiSisModComponentes(SiSisModComponentes siSisModComponentes) {
        this.siSisModComponentes = siSisModComponentes;
    }

    public String getDihlhludescr() {
        return dihlhludescr;
    }

    public void setDihlhludescr(String dihlhludescr) {
        this.dihlhludescr = dihlhludescr;
    }

}
