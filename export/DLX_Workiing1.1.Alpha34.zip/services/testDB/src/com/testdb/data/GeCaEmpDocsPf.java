
package com.testdb.data;



/**
 *  testDB.GeCaEmpDocsPf
 *  02/23/2013 10:50:05
 * 
 */
public class GeCaEmpDocsPf {

    private Integer geempdpfempresaid;
    private GeCaEmpresas geCaEmpresas;
    private com.testdb.data.GeTbUf geTbUfByGeempdpfrguf;
    private com.testdb.data.GeTbUf geTbUfByGeempdpfregprofuf;
    private String geempdpfcpf;
    private String geempdpfrg;
    private String geempdpfrgorgao;
    private String geempdpfregprof;

    public Integer getGeempdpfempresaid() {
        return geempdpfempresaid;
    }

    public void setGeempdpfempresaid(Integer geempdpfempresaid) {
        this.geempdpfempresaid = geempdpfempresaid;
    }

    public GeCaEmpresas getGeCaEmpresas() {
        return geCaEmpresas;
    }

    public void setGeCaEmpresas(GeCaEmpresas geCaEmpresas) {
        this.geCaEmpresas = geCaEmpresas;
    }

    public com.testdb.data.GeTbUf getGeTbUfByGeempdpfrguf() {
        return geTbUfByGeempdpfrguf;
    }

    public void setGeTbUfByGeempdpfrguf(com.testdb.data.GeTbUf geTbUfByGeempdpfrguf) {
        this.geTbUfByGeempdpfrguf = geTbUfByGeempdpfrguf;
    }

    public com.testdb.data.GeTbUf getGeTbUfByGeempdpfregprofuf() {
        return geTbUfByGeempdpfregprofuf;
    }

    public void setGeTbUfByGeempdpfregprofuf(com.testdb.data.GeTbUf geTbUfByGeempdpfregprofuf) {
        this.geTbUfByGeempdpfregprofuf = geTbUfByGeempdpfregprofuf;
    }

    public String getGeempdpfcpf() {
        return geempdpfcpf;
    }

    public void setGeempdpfcpf(String geempdpfcpf) {
        this.geempdpfcpf = geempdpfcpf;
    }

    public String getGeempdpfrg() {
        return geempdpfrg;
    }

    public void setGeempdpfrg(String geempdpfrg) {
        this.geempdpfrg = geempdpfrg;
    }

    public String getGeempdpfrgorgao() {
        return geempdpfrgorgao;
    }

    public void setGeempdpfrgorgao(String geempdpfrgorgao) {
        this.geempdpfrgorgao = geempdpfrgorgao;
    }

    public String getGeempdpfregprof() {
        return geempdpfregprof;
    }

    public void setGeempdpfregprof(String geempdpfregprof) {
        this.geempdpfregprof = geempdpfregprof;
    }

}
