
package com.testdb.data;



/**
 *  testDB.StEpFabricWeb
 *  02/23/2013 10:50:04
 * 
 */
public class StEpFabricWeb {

    private Integer stfawebid;
    private StEpFabricantes stEpFabricantes;
    private GeTbTiposTelefone geTbTiposTelefone;
    private String stfawebtxt;

    public Integer getStfawebid() {
        return stfawebid;
    }

    public void setStfawebid(Integer stfawebid) {
        this.stfawebid = stfawebid;
    }

    public StEpFabricantes getStEpFabricantes() {
        return stEpFabricantes;
    }

    public void setStEpFabricantes(StEpFabricantes stEpFabricantes) {
        this.stEpFabricantes = stEpFabricantes;
    }

    public GeTbTiposTelefone getGeTbTiposTelefone() {
        return geTbTiposTelefone;
    }

    public void setGeTbTiposTelefone(GeTbTiposTelefone geTbTiposTelefone) {
        this.geTbTiposTelefone = geTbTiposTelefone;
    }

    public String getStfawebtxt() {
        return stfawebtxt;
    }

    public void setStfawebtxt(String stfawebtxt) {
        this.stfawebtxt = stfawebtxt;
    }

}
