
package com.testdb.data;

import java.util.Date;


/**
 *  testDB.GeCaEmpCentrocusto
 *  02/23/2013 10:50:04
 * 
 */
public class GeCaEmpCentrocusto {

    private Integer geempccuid;
    private GeCaEmpresas geCaEmpresas;
    private String geempccucodigo;
    private String geempccunome;
    private String geempccunomeabre;
    private String geempccustatus;
    private Date geempccuvigdesde;
    private Date geempccuvigate;

    public Integer getGeempccuid() {
        return geempccuid;
    }

    public void setGeempccuid(Integer geempccuid) {
        this.geempccuid = geempccuid;
    }

    public GeCaEmpresas getGeCaEmpresas() {
        return geCaEmpresas;
    }

    public void setGeCaEmpresas(GeCaEmpresas geCaEmpresas) {
        this.geCaEmpresas = geCaEmpresas;
    }

    public String getGeempccucodigo() {
        return geempccucodigo;
    }

    public void setGeempccucodigo(String geempccucodigo) {
        this.geempccucodigo = geempccucodigo;
    }

    public String getGeempccunome() {
        return geempccunome;
    }

    public void setGeempccunome(String geempccunome) {
        this.geempccunome = geempccunome;
    }

    public String getGeempccunomeabre() {
        return geempccunomeabre;
    }

    public void setGeempccunomeabre(String geempccunomeabre) {
        this.geempccunomeabre = geempccunomeabre;
    }

    public String getGeempccustatus() {
        return geempccustatus;
    }

    public void setGeempccustatus(String geempccustatus) {
        this.geempccustatus = geempccustatus;
    }

    public Date getGeempccuvigdesde() {
        return geempccuvigdesde;
    }

    public void setGeempccuvigdesde(Date geempccuvigdesde) {
        this.geempccuvigdesde = geempccuvigdesde;
    }

    public Date getGeempccuvigate() {
        return geempccuvigate;
    }

    public void setGeempccuvigate(Date geempccuvigate) {
        this.geempccuvigate = geempccuvigate;
    }

}
