
package com.testdb;



/**
 *  Query names for service "testDB"
 *  02/23/2013 12:10:10
 * 
 */
public class TestDBConstants {

    public final static String getSiCliModuloByIdQueryName = "getSiCliModuloById";

}
