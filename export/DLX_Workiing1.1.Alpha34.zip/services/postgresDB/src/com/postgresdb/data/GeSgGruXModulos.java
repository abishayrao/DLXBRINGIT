
package com.postgresdb.data;



/**
 *  postgresDB.GeSgGruXModulos
 *  01/23/2013 09:59:13
 * 
 */
public class GeSgGruXModulos {

    private Integer gesggxmid;
    private GeSgGrupos geSgGrupos;
    private Integer gesggxmidmod;

    public Integer getGesggxmid() {
        return gesggxmid;
    }

    public void setGesggxmid(Integer gesggxmid) {
        this.gesggxmid = gesggxmid;
    }

    public GeSgGrupos getGeSgGrupos() {
        return geSgGrupos;
    }

    public void setGeSgGrupos(GeSgGrupos geSgGrupos) {
        this.geSgGrupos = geSgGrupos;
    }

    public Integer getGesggxmidmod() {
        return gesggxmidmod;
    }

    public void setGesggxmidmod(Integer gesggxmidmod) {
        this.gesggxmidmod = gesggxmidmod;
    }

}
