
package com.postgresdb;



/**
 *  Query names for service "postgresDB"
 *  01/23/2013 09:59:10
 * 
 */
public class PostgresDBConstants {

    public final static String getGeCaEmpDocsPfByIdQueryName = "getGeCaEmpDocsPfById";

}
