{
	"FP": {
		"_classes": {
			"domNode": [
			]
		}, 
		"styles": {
			"backgroundColor": "", 
			"color": "#ffffff", 
			"fontSize": ""
		}
	}, 
	"button1": {
		"_classes": {
			"domNode": [
			]
		}, 
		"iconHeight": "10%", 
		"iconWidth": "20%"
	}, 
	"formPanel1": {
		"_classes": {
			"domNode": [
			]
		}
	}, 
	"label1": {
		"_classes": {
			"domNode": [
			]
		}, 
		"styles": {
			"color": "#ffffff", 
			"fontSize": "14px"
		}
	}, 
	"label2": {
		"_classes": {
			"domNode": [
			]
		}, 
		"styles": {
			"color": "#ffffff", 
			"fontSize": "14px"
		}
	}, 
	"label3": {
		"_classes": {
			"domNode": [
			]
		}, 
		"styles": {
			"color": "#ffffff", 
			"fontSize": "16px"
		}, 
		"width": "31px"
	}, 
	"label4": {
		"_classes": {
			"domNode": [
			]
		}, 
		"deviceType": [
			"desktop"
		], 
		"styles": {
			"color": "#ffffff", 
			"fontSize": "16px"
		}, 
		"width": "40px"
	}, 
	"layoutBox1": {
		"_classes": {
			"domNode": [
			]
		}, 
		"styles": {
			"backgroundImage": "resources/images/bg/w1-4px.jpg", 
			"backgroundRepeat": "repeat", 
			"opacity": 0.95
		}
	}, 
	"panel1": {
		"_classes": {
			"domNode": [
			]
		}
	}, 
	"panel2": {
		"_classes": {
			"domNode": [
			]
		}
	}, 
	"picture1": {
		"_classes": {
			"domNode": [
			]
		}
	}, 
	"text1": {
		"_classes": {
			"domNode": [
			]
		}, 
		"styles": {
			"color": "#ffffff"
		}
	}, 
	"text2": {
		"_classes": {
			"domNode": [
			]
		}, 
		"styles": {
			"color": "#ffffff"
		}
	}, 
	"SCRIPT_New Term1": "Authenticated!"
}