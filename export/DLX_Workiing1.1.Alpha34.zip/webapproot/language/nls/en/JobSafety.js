{
	"ByCNPJ": {
		"_classes": {
			"domNode": []
		}
	},
	"ByCode": {
		"_classes": {
			"domNode": []
		}
	},
	"ByDate": {
		"_classes": {
			"domNode": []
		}
	},
	"ByName": {
		"_classes": {
			"domNode": []
		}
	},
	"DefaultLayer": {
		"_classes": {
			"domNode": []
		}
	},
	"English": {
		"_classes": {
			"domNode": []
		}
	},
	"Filter": {
		"_classes": {
			"domNode": []
		}
	},
	"FilterAndLocation": {
		"_classes": {
			"domNode": []
		}
	},
	"FilterLocationLabel": {
		"_classes": {
			"domNode": []
		},
		"styles": {
			"fontWeight": "bold"
		}
	},
	"FilterOrLocationPanel": {
		"_classes": {
			"domNode": []
		}
	},
	"FilterTypeLabel": {
		"_classes": {
			"domNode": []
		},
		"styles": {
			"fontWeight": "bold"
		}
	},
	"FilterTypePanel": {
		"_classes": {
			"domNode": []
		}
	},
	"GroupsProfiles": {
		"_classes": {
			"domNode": []
		}
	},
	"GroupsProfilesLabel": {
		"_classes": {
			"domNode": []
		},
		"styles": {
			"fontWeight": "bold"
		}
	},
	"GroupsTab": {
		"_classes": {
			"domNode": []
		}
	},
	"LayerPanel": {
		"_classes": {
			"domNode": []
		}
	},
	"LocateButton": {
		"_classes": {
			"domNode": []
		}
	},
	"Location": {
		"_classes": {
			"domNode": []
		}
	},
	"Location3": {
		"_classes": {
			"domNode": []
		}
	},
	"Maintenance": {
		"_classes": {
			"domNode": []
		}
	},
	"MaintenanceTabs": {
		"_classes": {
			"domNode": []
		}
	},
	"MenuonSide": {
		"_classes": {
			"domNode": []
		}
	},
	"ModulesTab": {
		"_classes": {
			"domNode": []
		}
	},
	"Portuguese": {
		"_classes": {
			"domNode": []
		}
	},
	"Privacy_Policy": {
		"_classes": {
			"domNode": ["wm_FontSizePx_10px"]
		}
	},
	"ResetButton": {
		"_classes": {
			"domNode": []
		}
	},
	"SituationLabel": {
		"_classes": {
			"domNode": []
		},
		"styles": {
			"fontWeight": "bold"
		}
	},
	"Situation_Active": {
		"_classes": {
			"domNode": []
		}
	},
	"Situation_InActive": {
		"_classes": {
			"domNode": []
		}
	},
	"Situation_Panel": {
		"_classes": {
			"domNode": []
		}
	},
	"TermsOfUse": {
		"_classes": {
			"domNode": ["wm_FontSizePx_10px"]
		}
	},
	"UpperPanel": {
		"_classes": {
			"domNode": []
		}
	},
	"UsersTab": {
		"_classes": {
			"domNode": []
		}
	},
	"button1Panel": {
		"_classes": {
			"domNode": []
		}
	},
	"dojoGrid1": {
		"_classes": {
			"domNode": []
		},
		"desktopHeight": "90%",
		"height": "90%",
		"localizationStructure": {
			"Name": "Name",
			"PHONE COLUMN": "-"
		},
		"mobileHeight": "90%"
	},
	"dojoMenu1": {
		"_classes": {
			"domNode": ["ClickableDojoMenu"]
		},
		"localizationStructure": {
			"Accidents": "Accidents",
			"Action Plan": "Action Plan",
			"CIPA": "CIPA",
			"Fire Brigade": "Fire Brigade",
			"Maintenance": "Maintenance",
			"PPRA": "PPRA",
			"Protective Equipment": "Protective Equipment"
		}
	},
	"label1": {
		"_classes": {
			"domNode": ["wm_FontSizePx_10px"]
		}
	},
	"label3": {
		"_classes": {
			"domNode": []
		},
		"width": "262px"
	},
	"label4": {
		"_classes": {
			"domNode": []
		}
	},
	"layoutBox1": {
		"_classes": {
			"domNode": []
		}
	},
	"logoutButton": {
		"_classes": {
			"domNode": []
		}
	},
	"panel1": {
		"_classes": {
			"domNode": []
		}
	},
	"panel10": {
		"_classes": {
			"domNode": []
		},
		"width": "402px"
	},
	"panel11": {
		"_classes": {
			"domNode": []
		}
	},
	"panel15": {
		"_classes": {
			"domNode": []
		}
	},
	"panel2": {
		"_classes": {
			"domNode": []
		}
	},
	"panel3": {
		"_classes": {
			"domNode": []
		}
	},
	"panel5": {
		"_classes": {
			"domNode": []
		}
	},
	"panel6": {
		"_classes": {
			"domNode": []
		}
	},
	"panel7": {
		"_classes": {
			"domNode": []
		}
	},
	"panel8": {
		"_classes": {
			"domNode": []
		}
	},
	"panel9": {
		"_classes": {
			"domNode": []
		}
	},
	"picture1": {
		"_classes": {
			"domNode": []
		}
	},
	"picture2": {
		"_classes": {
			"domNode": []
		}
	},
	"selectLanguage": {
		"_classes": {
			"domNode": []
		}
	},
	"spacer1": {
		"_classes": {
			"domNode": []
		}
	},
	"spacer2": {
		"_classes": {
			"domNode": []
		}
	},
	"spacer3": {
		"_classes": {
			"domNode": []
		}
	},
	"spacer4": {
		"_classes": {
			"domNode": []
		}
	},
	"spacer5": {
		"_classes": {
			"domNode": []
		}
	}
}