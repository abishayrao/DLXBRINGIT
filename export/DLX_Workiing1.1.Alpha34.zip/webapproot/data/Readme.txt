This data directory is for HSQLDB Databases.

By default, it contains some sample databases.
If your project does not use these sample database, you can delete these files and directory to reduce the size of your project.

You can also add your own HSQLDB database or other data files to this directory. All HSQLDB databases must be in this diretory.
